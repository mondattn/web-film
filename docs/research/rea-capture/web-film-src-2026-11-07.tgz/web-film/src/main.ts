import './styles/base.css';
import './styles/nguonc-redesign.css';
import './styles/overrides.css';

import { renderHeader } from './header';
import { escapeHtml, route, startRouter, type RouteContext } from './router';
import { renderFilmPage } from './pages/film';

const SAMPLE_SLUG = 'bac-si-x';

function stubPage(title: string, note: string) {
    return ({ outlet, path, query }: RouteContext) => {
        document.title = `${title} · WEB FILM`;
        const keyword = query.get('keyword');
        outlet.innerHTML = `<div class="nc-stub">
            <h1>${escapeHtml(title)}${keyword ? `: “${escapeHtml(keyword)}”` : ''}</h1>
            <p>${escapeHtml(note)}</p>
            <p><code>${escapeHtml(path)}${keyword ? `?keyword=${escapeHtml(keyword)}` : ''}</code></p>
            <p><a class="nc-button nc-button--primary" href="/phim/${SAMPLE_SLUG}">Xem trang phim mẫu</a></p>
        </div>`;
    };
}

route('/', ({ outlet }) => {
    document.title = 'WEB FILM';
    outlet.innerHTML = `<div class="nc-stub">
        <h1>WEB FILM</h1>
        <p>Bản dựng lại trang chi tiết phim của Nguồn C. Mở <code>/phim/&lt;slug&gt;</code> với slug bất kỳ có trên nguonc.com.</p>
        <p><a class="nc-button nc-button--primary" href="/phim/${SAMPLE_SLUG}">Bác Sĩ X</a></p>
    </div>`;
});
route('/phim/:slug', renderFilmPage);

const LIST_NOTE = 'Trang danh sách chưa được dựng — mới có trang chi tiết phim. API gốc có sẵn endpoint tương ứng (xem README).';
route('/danh-sach/:slug', stubPage('Danh sách', LIST_NOTE));
route('/the-loai/:slug', stubPage('Thể loại', LIST_NOTE));
route('/quoc-gia/:slug', stubPage('Quốc gia', LIST_NOTE));
route('/nam-phat-hanh/:slug', stubPage('Năm phát hành', LIST_NOTE));
route('/tim-kiem', stubPage('Tìm kiếm', 'Trang tìm kiếm chưa được dựng. API gốc: GET /api/films/search?keyword=…'));

renderHeader();
startRouter();
