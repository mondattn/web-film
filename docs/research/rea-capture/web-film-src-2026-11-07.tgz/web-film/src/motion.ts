/* Hiệu ứng hiện dần khi vào viewport (redesign.js › Phase UI-8), rút gọn cho trang phim. */

const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
const supported = typeof Element !== 'undefined' && !!Element.prototype.animate && 'IntersectionObserver' in window;
const staticMotion = reduced || !supported;
document.documentElement.classList.add(staticMotion ? 'nc-motion-static' : 'nc-motion-enabled');

const observer = staticMotion ? null : new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        observer!.unobserve(entry.target);
        play(entry.target as HTMLElement);
    });
}, { rootMargin: '0px 0px -7% 0px', threshold: 0.06 });

function play(element: HTMLElement): void {
    const delay = Number(element.dataset.ncMotionDelay ?? 0);
    const compact = window.innerWidth < 768;
    const distance = compact ? 9 : 15;
    element.animate([
        { opacity: 0, transform: `translate3d(0, ${distance}px, 0) scale(0.975)` },
        { opacity: 1, transform: 'translate3d(0, 0, 0) scale(1)' },
    ], { duration: compact ? 460 : 620, delay, easing: 'cubic-bezier(0.22, 1, 0.36, 1)', fill: 'backwards' });
}

/** Đăng ký .nc-film-hero và .nc-detail-card trong scope (delay 34 ms/card, tối đa 170 ms). */
export function revealCards(scope: HTMLElement): void {
    scope.querySelectorAll<HTMLElement>('.nc-film-hero, .nc-detail-card').forEach((element, index) => {
        if (element.dataset.ncMotionBound === 'true') return;
        element.dataset.ncMotionBound = 'true';
        element.dataset.ncMotionKind = 'card';
        element.dataset.ncMotionDelay = String(Math.min(index * 34, 170));
        observer?.observe(element);
    });
}
