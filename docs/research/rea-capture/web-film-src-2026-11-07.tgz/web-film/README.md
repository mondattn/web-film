# web-film

Dựng lại trang chi tiết phim của Nguồn C (`https://phim.nguonc.com/phim/<slug>`) bằng **Vite + TypeScript thuần**, dữ liệu lấy trực tiếp từ API công khai `https://phim.nguonc.com/api/film/{slug}`.

Bản tham chiếu: `https://phim.nguonc.com/phim/bac-si-x` — capture bằng REA ngày 2026-11-07 (DOM, CSS, JS, network, screenshot 1440×2600 ở trạng thái đóng/mở trình phát/mở nguồn embed).

## Chạy

```bash
npm install
npm run dev        # http://127.0.0.1:5176/phim/bac-si-x
npm run build      # dist/
npm run typecheck
```

Route `/phim/<slug>` nhận slug bất kỳ có trên nguonc (ví dụ `/phim/bac-si-x`). Trang chủ `/` và các route danh sách (`/danh-sach/*`, `/the-loai/*`, `/quoc-gia/*`, `/nam-phat-hanh/*`, `/tim-kiem`) hiện là trang placeholder — bản gốc không được capture cho các trang này.

## Cấu trúc

```
index.html                 shell (script chống nháy theme, header/main/footer/drawer rỗng)
src/main.ts                nạp CSS, đăng ký route, render header
src/router.ts              router pushState + chặn link nội bộ + cuộn tới #anchor
src/api.ts                 kiểu dữ liệu + fetchFilm(slug) + tiện ích đọc category → tag/link
src/menu.ts                dữ liệu menu header (thể loại / quốc gia / năm, slug như site gốc)
src/icons.ts               SVG inline của bản gốc
src/header.ts              header + drawer di động + theme + thanh tiến trình cuộn
src/pages/film.ts          markup trang phim từ ApiMovie (breadcrumb, hero, facts, 2 card)
src/player.ts              trình phát + nguồn embed (port từ film-player.js của bản gốc)
src/motion.ts              reveal card khi vào viewport (Phase UI-8 của bản gốc, rút gọn)
src/styles/base.css        reset kiểu Tailwind preflight + vài rule index.css + phần riêng của clone
src/styles/nguonc-redesign.css   redesign.css của bản gốc, GIỮ NGUYÊN (design reference, 82 KB)
src/styles/overrides.css   public-overrides.css (phần trang phim dùng)
docs/research/nguonc/      HTML gốc, JSON API, poster thumb (fixture cho QA offline)
qa/shot.mjs                chụp bằng Playwright (offline, stub API/poster) để so với ảnh REA
```

## API Nguồn C (từ `GET /api`)

| Method | Path | Ghi chú |
|---|---|---|
| GET | `/api/film/{slug}` | Chi tiết phim + tập (dùng cho trang này). Có `access-control-allow-origin: *`. |
| GET | `/api/films/phim-moi-cap-nhat?page=` | Phim mới cập nhật |
| GET | `/api/films/danh-sach/{slug}?page=` | Theo danh mục (phim-bo, phim-le, tv-shows, phim-ai) |
| GET | `/api/films/the-loai/{slug}?page=` | Theo thể loại |
| GET | `/api/films/quoc-gia/{slug}?page=` | Theo quốc gia |
| GET | `/api/films/nam-phat-hanh/{slug}?page=` | Theo năm |
| GET | `/api/films/ngon-ngu/{slug}?page=` | Theo ngôn ngữ (vietsub, …) |
| GET | `/api/films/search?keyword=&page=` | Tìm kiếm |

Bản gốc là trang server-render (jQuery); danh sách tập được tải riêng từ `/phim/<slug>/episodes` (same-origin, không có CORS). Clone lấy luôn `movie.episodes[].server_name/items` từ `/api/film/{slug}` — cùng dữ liệu.

## Khác với bản gốc (DEVIATION / ASSUMPTION)

- **Logo**: bản gốc dùng ảnh PNG "NGUONC" đỏ; clone dùng wordmark chữ "WEB FILM" (cùng chiều rộng 150 px để layout header không đổi).
- **Nền trang**: ảnh `bg-dark.png` (quầng sáng góc trên phải, 90 rem) không lấy được qua REA (vượt ngân sách 64 KB body) → vẽ lại bằng `radial-gradient` trong `.nc-backdrop`.
- **Font**: giữ nguyên stack `Inter, ui-sans-serif, system-ui, …` của bản gốc (bản gốc không nạp Inter, nên trên Mac cả hai đều render bằng SF Pro). Không nạp Google Fonts (Open Sans/Dosis) vì trang phim không dùng tới.
- **Màu nhãn trạng thái** (`nc-film-status--ongoing/complete/neutral`): bản gốc chỉ quan sát được "Tập 10" → ongoing; luật "Hoàn tất/Full/Trọn bộ → complete, còn lại neutral" là ASSUMPTION.
- **Link thể loại/quốc gia trong hero**: slug sinh từ tên (`slugify`) — vài slug của site gốc khác tên (Hài → `phim-hai`, Nhạc → `phim-nhac`, Ca-na-đa → `canada`…); menu header dùng slug thật, link trong facts có thể lệch với các trường hợp này.
- **Không có**: Cloudflare RUM, JSON-LD, nprogress/ajax-load của Hn_Framework, trang danh sách/tìm kiếm.
- Hành vi trình phát, tìm tập, định dạng nguồn embed, lưu tập đang xem (`localStorage nguonc:player-progress:v1:<slug>`), fallback 12 s "Trình phát tải lâu hơn dự kiến", theme (`localStorage theme`, mặc định tối): giữ đúng như film-player.js / main.js của bản gốc.

## QA

```bash
npx vite preview --port 4173 &
node qa/shot.mjs http://127.0.0.1:4173 qa/shots                      # trạng thái đóng
node qa/shot.mjs http://127.0.0.1:4173 qa/shots --open-player --open-sources
```

Kết quả 2026-11-07 (viewport 1440×2600, so với ảnh REA của bản gốc): viền hero ở y=145, cột 80/105/284 trùng; card nguồn embed / trình phát / lưới tập trùng vị trí; khác biệt còn lại là font (Linux vs macOS) và wordmark.
